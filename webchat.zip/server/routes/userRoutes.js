import express from "express";
import {
  checkAuth,
  login,
  signup,
  updateProfile,
} from "../controllers/userController.js";
import { protectRoute } from "../middleware/auth.js";
import User from "../models/User.js"; // ✅ fixed import (file is User.js, not userModel.js)

const userRouter = express.Router();

userRouter.post("/signup", signup);
userRouter.post("/login", login);
userRouter.put("/update-profile", protectRoute, updateProfile);
userRouter.get("/check", protectRoute, checkAuth);

// ✅ New route: get all users except logged-in one
userRouter.get("/users", protectRoute, async (req, res) => {
  try {
    const users = await User.find({ _id: { $ne: req.user._id } }).select(
      "-password"
    );

    res.json({
      success: true,
      users,
      unseenMessages: {}, // you can later replace this with real unseen message count
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

export default userRouter;
