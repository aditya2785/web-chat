import express from "express";
import "dotenv/config";
import cors from "cors";
import http from "http";
import { connectDB } from "./lib/db.js";
import userRouter from "./routes/UserRoutes.js";
import messageRouter from "./routes/messageRoutes.js";
import { Server } from "socket.io";
import User from "./models/User.js";       // ✅ Fixed import
import Message from "./models/message.js"; // ✅ Fixed import

const app = express();
const server = http.createServer(app);

const CLIENT_URL = process.env.CLIENT_URL || "http://localhost:5173";

export const io = new Server(server, {
  cors: {
    origin: CLIENT_URL,
    credentials: true,
  },
});

export const userSocketMap = {};

io.on("connection", (socket) => {
  const userId = socket.handshake.query.userId;
  console.log("User Connected", userId);

  if (userId) userSocketMap[userId] = socket.id;

  io.emit("getOnlineUsers", Object.keys(userSocketMap));

  socket.on("disconnect", () => {
    console.log("User Disconnected", userId);
    delete userSocketMap[userId];
    io.emit("getOnlineUsers", Object.keys(userSocketMap));
  });
});

// Middleware
app.use(express.json({ limit: "4mb" }));
app.use(
  cors({
    origin: CLIENT_URL,
    credentials: true,
  })
);

// ✅ Fixed /api/status route
app.get("/api/status", async (req, res) => {
  try {
    const authUserId = req.query.userId;

    // fetch all users except the logged-in one
    const users = await User.find(authUserId ? { _id: { $ne: authUserId } } : {}).select("-password");

    // unseen messages count
    const unseenMessages = {};
    if (authUserId) {
      const unreadMsgs = await Message.find({
        receiverId: authUserId,
        seen: false,
      });

      unreadMsgs.forEach((msg) => {
        unseenMessages[msg.senderId] = (unseenMessages[msg.senderId] || 0) + 1;
      });
    }

    res.json({
      success: true,
      users,
      unseenMessages,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.use("/api/auth", userRouter);
app.use("/api/messages", messageRouter);

await connectDB();

const PORT = process.env.PORT || 5000;
app.get("/", (req, res) => {
  res.send("Backend is running!");
});
server.listen(PORT, () => console.log("Server is running on PORT:", PORT));
